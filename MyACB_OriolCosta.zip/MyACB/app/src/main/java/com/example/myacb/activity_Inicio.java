package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_Inicio extends AppCompatActivity {

    Button bot_IrIniciarSesInv;

    Button bot_IrRegistro;

    Button bot_IrIniciarSes;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        bot_IrIniciarSesInv=(Button)findViewById(R.id.bot_IrIniciarSesInv);
        bot_IrRegistro=(Button)findViewById(R.id.bot_IrRegistro);
        bot_IrIniciarSes=(Button)findViewById(R.id.bot_IrIniciarSes);

        /*   Ir a capas     */

        bot_IrIniciarSesInv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent( activity_Inicio.this, activity_Home.class);
                startActivity(i);
            }
        });

        bot_IrRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent( activity_Inicio.this, activity_Registro.class);
                startActivity(i);
            }
        });

        bot_IrIniciarSes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent( activity_Inicio.this, activity_IniciarSes.class);
                startActivity(i);
            }
        });
    }
}