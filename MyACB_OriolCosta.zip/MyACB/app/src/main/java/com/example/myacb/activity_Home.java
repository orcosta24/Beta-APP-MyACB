package com.example.myacb;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class activity_Home extends AppCompatActivity {

    Button bot_HHome;
    Button bot_HIrEquipo;
    Button bot_HIrCalendario;
    Button bot_HIrGanadores;
    Button bot_HIrSoporte;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bot_HHome=(Button)findViewById(R.id.bot_HHome);
        bot_HIrEquipo=(Button)findViewById(R.id.bot_HIrEquipo);
        bot_HIrCalendario=(Button)findViewById(R.id.bot_HIrCalendario);
        bot_HIrGanadores=(Button)findViewById(R.id.bot_HIrGanadores);
        bot_HIrSoporte=(Button)findViewById(R.id.bot_HIrSoporte);



        /*   Capa Home     */

        bot_HHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_Home.this, "Ya estás en la página home", Toast.LENGTH_SHORT).show();
            }});

        /*   Ir a capas     */

        bot_HIrEquipo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Home.this, activity_equipos.class);
                startActivity(i);
            }
        });

        bot_HIrCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Home.this, activity_Calendario.class);
                startActivity(i);
            }
        });

        bot_HIrGanadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Home.this, activity_Ganadores.class);
                startActivity(i);
            }
        });

        bot_HIrSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Home.this, activity_Soporte.class);
                startActivity(i);
            }
        });



    }
}