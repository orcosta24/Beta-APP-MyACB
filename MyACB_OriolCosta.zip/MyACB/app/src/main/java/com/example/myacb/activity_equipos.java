package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class activity_equipos extends AppCompatActivity {
    Button bot_EIrHome;
    Button bot_EEquipo;
    Button bot_EIrCalendario;
    Button bot_EIrGanadores;
    Button bot_EIrSoporte;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equipos);
        bot_EIrHome = (Button) findViewById(R.id.bot_EIrHome);
        bot_EEquipo = (Button) findViewById(R.id.bot_EEquipo);
        bot_EIrCalendario = (Button) findViewById(R.id.bot_EIrCalendario);
        bot_EIrGanadores = (Button) findViewById(R.id.bot_EIrGanadores);
        bot_EIrSoporte = (Button) findViewById(R.id.bot_EIrSoporte);


        /*   Capa Home     */

        bot_EEquipo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_equipos.this, "Ya estás en la página Equipos", Toast.LENGTH_SHORT).show();
            }});

        /*   Ir a capas     */

        bot_EIrHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_equipos.this, activity_Home.class);
                startActivity(i);
            }
        });

        bot_EIrCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_equipos.this, activity_Calendario.class);
                startActivity(i);
            }
        });

        bot_EIrGanadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_equipos.this, activity_Ganadores.class);
                startActivity(i);
            }
        });

        bot_EIrSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_equipos.this, activity_Soporte.class);
                startActivity(i);
            }
        });

    }
}