package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class activity_Calendario extends AppCompatActivity {
    Button bot_CIrHome;
    Button bot_CIrEquipos;
    Button bot_CCalendario;
    Button bot_CIrGanadores;
    Button bot_CIrSoporte;

    Button bot_Regular;

    Button bot_CRey;

    Button bot_SRey;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);
        bot_CIrHome = (Button) findViewById(R.id.bot_CIrHome);
        bot_CIrEquipos = (Button) findViewById(R.id.bot_CIrEquipos);
        bot_CCalendario = (Button) findViewById(R.id.bot_CCalendario);
        bot_CIrGanadores = (Button) findViewById(R.id.bot_CIrGanadores);
        bot_CIrSoporte = (Button) findViewById(R.id.bot_CIrSoporte);

        bot_Regular = (Button) findViewById(R.id.botRegular);
        bot_CRey = (Button) findViewById(R.id.botCRey);
        bot_SRey = (Button) findViewById(R.id.botSRey);


        /* NAVEGACION ENTRE LIGAS*/

        bot_Regular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_calendario_regular.class);
                startActivity(i);
            }
        });

        bot_CRey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_calendario_crey.class);
                startActivity(i);
            }
        });

        bot_SRey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_calendario_srey.class);
                startActivity(i);
            }
        });

        /*   NAVEGACION    */

        bot_CCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_Calendario.this, "Ya estás en la página Calendario", Toast.LENGTH_SHORT).show();
            }});

        /*   Ir a capas     */

        bot_CIrHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_Home.class);
                startActivity(i);
            }
        });

        bot_CIrEquipos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_equipos.class);
                startActivity(i);
            }
        });

        bot_CIrGanadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_Ganadores.class);
                startActivity(i);
            }
        });

        bot_CIrSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Calendario.this, activity_Soporte.class);
                startActivity(i);
            }
        });

    }

}