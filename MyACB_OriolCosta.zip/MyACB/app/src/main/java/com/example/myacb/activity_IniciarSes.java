package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activity_IniciarSes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_ses);
    }
}