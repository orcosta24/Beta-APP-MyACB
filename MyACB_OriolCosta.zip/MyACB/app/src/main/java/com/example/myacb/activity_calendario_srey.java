package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_calendario_srey extends AppCompatActivity {
    Button bot_atras;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario_srey);
        bot_atras = (Button) findViewById(R.id.bot_atras3);


        /* NAVEGACION ENTRE LIGAS*/

        bot_atras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_calendario_srey.this, activity_Calendario.class);
                startActivity(i);
            }
        });
}}