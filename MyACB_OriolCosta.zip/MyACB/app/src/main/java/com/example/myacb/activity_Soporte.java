package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activity_Soporte extends AppCompatActivity {

    Button bot_SIrHome;
    Button bot_SIrEquipos;
    Button bot_SIrCalendario;
    Button bot_SIrGanadores;
    Button bot_SSoporte;

    /* BOTONES ENVIAR  */
    EditText TextoContacto;

    Button bot_Enviar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soporte);
        bot_SIrHome = (Button) findViewById(R.id.bot_SIrHome);
        bot_SIrEquipos = (Button) findViewById(R.id.bot_SIrEquipos);
        bot_SIrCalendario = (Button) findViewById(R.id.bot_SIrCalendario);
        bot_SIrGanadores = (Button) findViewById(R.id.bot_SIrGanadores);
        bot_SSoporte = (Button) findViewById(R.id.bot_SSoporte);
        TextoContacto = (EditText) findViewById(R.id.TextoContacto);
        bot_Enviar = (Button) findViewById(R.id.bot_Enviar);

        /* FUNCION ENVIAR MENSAJE E REINICIAR EDITTEXT */

        bot_Enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_Soporte.this, "Comentario enviado, ¡Gracias por tu ayuda!", Toast.LENGTH_SHORT).show();
                TextoContacto.setText("");
            }
        });

        /*   Capa Home     */

        bot_SSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_Soporte.this, "Ya estás en la página Soporte", Toast.LENGTH_SHORT).show();
            }});


        /*   Ir a capas     */

        bot_SIrHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Soporte.this, activity_Home.class);
                startActivity(i);
            }
        });

        bot_SIrEquipos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Soporte.this, activity_equipos.class);
                startActivity(i);
            }
        });

        bot_SIrCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Soporte.this, activity_Calendario.class);
                startActivity(i);
            }
        });

        bot_SIrGanadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Soporte.this, activity_Ganadores.class);
                startActivity(i);
            }
        });


    }
}