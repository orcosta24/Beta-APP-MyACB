package com.example.myacb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class activity_Ganadores extends AppCompatActivity {

    Button bot_GIrHome;
    Button bot_GIrEquipos;
    Button bot_GIrCalendario;
    Button bot_GGanadores;
    Button bot_GIrSoporte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ganadores);
        bot_GIrHome = (Button) findViewById(R.id.bot_GIrHome);
        bot_GIrEquipos = (Button) findViewById(R.id.bot_GIrEquipos);
        bot_GIrCalendario = (Button) findViewById(R.id.bot_GIrCalendario);
        bot_GGanadores = (Button) findViewById(R.id.bot_GGanadores);
        bot_GIrSoporte = (Button) findViewById(R.id.bot_GIrSoporte);


        /*   Capa Home     */

        bot_GGanadores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(activity_Ganadores.this, "Ya estás en la página Ganadores", Toast.LENGTH_SHORT).show();
            }});


        /*   Ir a capas     */

        bot_GIrHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Ganadores.this, activity_Home.class);
                startActivity(i);
            }
        });

        bot_GIrEquipos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Ganadores.this, activity_equipos.class);
                startActivity(i);
            }
        });

        bot_GIrCalendario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Ganadores.this, activity_Calendario.class);
                startActivity(i);
            }
        });

        bot_GIrSoporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(activity_Ganadores.this, activity_Soporte.class);
                startActivity(i);
            }
        });

    }
}