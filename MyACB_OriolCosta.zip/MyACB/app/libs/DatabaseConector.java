<user-permission android:name="android.permission.Internet"/>

import android.os.AsyncTask;
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConector extends AsyncTask<Void, Void, Connection> {

    private static final String DB_URL = "jdbd:mysql";
    private static final String USER = "tu_usuario";
    private static final String PASS = "tu_contraseña";

    /**
     * @return
     */
    protected Connection DoInBackground(voids...void){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection();
        }

    }

}
